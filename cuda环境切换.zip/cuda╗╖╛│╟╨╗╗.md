1. 全局切换

   管理员运行CMD，复制如下：

   ```
   python G:\xumingyue\chenjin\change_cuda_env.py
   ```

   ![img](cuda环境切换.assets/wps1-1718289120170.jpg) 

   按指引完成后，重启cmd

   通过下述命令验证cuda环境变量是否切换：

   ```
   echo %cuda_path%
   ```

2. 更改某个终端的会话的cuda_path

   G:\xumingyue\chenjin\cuda_bat

   提供了对应bat用于切换终端的临时环境（仅针对该终端生效）

   直接拖拽至对应终端运行即可

   ![1718289168579](cuda环境切换.assets/1718289168579.png)

3. pycharm工程通过环境变量设置cuda

   https://www.cnblogs.com/music-liang/p/17246124.html

   第三种，如果路径包括空格请使用英文双引号包裹

   例如：

   CUDA_PATH="C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.4"

   为某个文件设置运行设置(run configuration)的时候，参考G:\xumingyue\chenjin\cuda_bat中各个版本的bat把对应的两个环境变量加上即可